package tdt4240.a2.listeners;

public abstract class StateChangeListener {

	public abstract void stateChanged();

}
