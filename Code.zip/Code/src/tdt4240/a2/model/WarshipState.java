package tdt4240.a2.model;

/**
 * Created by IntelliJ IDEA.
 * User: Perry
 * Date: 15.03.12
 * Time: 13:54
 * To change this template use File | Settings | File Templates.
 */
public enum WarshipState {
    NOT_HIT,
    HIT;
}
