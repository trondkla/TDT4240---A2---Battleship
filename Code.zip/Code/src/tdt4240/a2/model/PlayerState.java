package tdt4240.a2.model;

/**
 * Created by IntelliJ IDEA.
 * User: asus
 * Date: 20.03.12
 * Time: 14:21
 * To change this template use File | Settings | File Templates.
 */
public enum PlayerState {
    FIRE,
    OBSERVE;
}
